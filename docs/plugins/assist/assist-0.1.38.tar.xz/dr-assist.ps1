# dr-assist - AI agent design, coding, and deployment assistant
# This script wraps the dr-assist Python package using uv

$ErrorActionPreference = "Stop"

# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Handle --dr-plugin-manifest flag for CLI integration (must be fast, no deps)
if ($args.Count -gt 0 -and $args[0] -eq "--dr-plugin-manifest") {
    Write-Output '{"name":"assist","version":"0.1.38","description":"AI agent design, coding, and deployment assistant","authentication":true}'
    exit 0
}

# Check if uv is available
$uvPath = Get-Command uv -ErrorAction SilentlyContinue
if (-not $uvPath) {
    Write-Host "Error: dr-assist requires 'uv' (fast Python package manager)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Install uv:" -ForegroundColor Yellow
    Write-Host "  PowerShell:  irm https://astral.sh/uv/install.ps1 | iex"
    Write-Host "  Scoop:       scoop install uv"
    Write-Host ""
    Write-Host "Then retry: dr assist"
    exit 1
}

# Find ALL Windows wheels (win_amd64) - will match all Python versions
$WheelPattern = "*win_amd64*.whl"
$Wheels = Get-ChildItem -Path $ScriptDir -Filter $WheelPattern -ErrorAction SilentlyContinue

if ($Wheels.Count -eq 0) {
    Write-Host "Error: No compatible wheel found for Windows" -ForegroundColor Red
    Write-Host "Expected pattern: $WheelPattern"
    Write-Host "Available wheels:"
    Get-ChildItem -Path $ScriptDir -Filter "*.whl" | ForEach-Object { Write-Host "  $($_.Name)" }
    exit 1
}

# Multiple Python-version wheels can match (cp311/cp312/cp313). uv can't resolve
# two wheels for the same package in one invocation, so pick exactly one: newest
# supported version first.
$PythonVersions = @("3.13", "3.12", "3.11")
$SelectedWheel = $null
$PythonPin = $null
foreach ($pyver in $PythonVersions) {
    $cptag = "cp" + $pyver.Replace(".", "")
    $match = $Wheels | Where-Object { $_.Name -like "*$cptag*" } | Select-Object -First 1
    if ($match) {
        $SelectedWheel = $match
        $PythonPin = $pyver
        break
    }
}

if (-not $SelectedWheel) {
    Write-Host "Error: No wheel for this platform matches a supported Python version (3.11-3.13)" -ForegroundColor Red
    $Wheels | ForEach-Object { Write-Host "  $($_.Name)" }
    exit 1
}

# Clear Python-specific environment variables to prevent path contamination
$env:PYTHONPATH = $null
$env:PYTHONHOME = $null
$env:PYTHONSTARTUP = $null
$env:PYTHONNOUSERSITE = "1"

# Use a persistent venv instead of `uv run --with` to avoid extras resolution failing
# offline (mirrors dr-assist.sh's fix; see its comment for the offline-resolution history).
# Venv path includes the wheel filename so upgrades automatically get a fresh venv.
$CacheRoot = if ($env:XDG_CACHE_HOME) { $env:XDG_CACHE_HOME } else { Join-Path $env:USERPROFILE ".cache" }
$VenvName = "dr-assist-venv-" + [System.IO.Path]::GetFileNameWithoutExtension($SelectedWheel.Name)
$VenvDir = Join-Path $CacheRoot $VenvName
$VenvExe = Join-Path $VenvDir "Scripts\dr-assist.exe"

if (-not (Test-Path $VenvExe)) {
    & uv venv --clear --python $PythonPin $VenvDir
    & uv pip install --python (Join-Path $VenvDir "Scripts\python.exe") $SelectedWheel.FullName
}

& $VenvExe @args
exit $LASTEXITCODE
