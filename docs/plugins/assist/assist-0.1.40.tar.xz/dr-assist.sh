#!/usr/bin/env bash
# dr-assist - AI agent design, coding, and deployment assistant
# This script wraps the dr-assist Python package using uv

set -euo pipefail

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Handle --dr-plugin-manifest flag for CLI integration (must be fast, no deps)
if [[ "${1:-}" == "--dr-plugin-manifest" ]]; then
    cat << 'EOF'
{"name":"assist","version":"0.1.40","description":"AI agent design, coding, and deployment assistant","authentication":true}
EOF
    exit 0
fi

# Check if uv is available
if ! command -v uv &> /dev/null; then
    echo "Error: dr-assist requires 'uv' (fast Python package manager)" >&2
    echo "" >&2
    echo "Install uv:" >&2
    echo "  macOS/Linux:  curl -LsSf https://astral.sh/uv/install.sh | sh" >&2
    echo "  Homebrew:     brew install uv" >&2
    echo "" >&2
    echo "Then retry: dr assist" >&2
    exit 1
fi

# Detect platform and select compatible wheel
case "$(uname -s)-$(uname -m)" in
    Linux-x86_64)   WHEEL_PATTERN="*manylinux*x86_64*.whl" ;;
    Linux-aarch64)  WHEEL_PATTERN="*manylinux*aarch64*.whl" ;;
    Darwin-arm64)   WHEEL_PATTERN="*macosx*arm64*.whl" ;;
    Darwin-x86_64)  WHEEL_PATTERN="*macosx*x86_64*.whl" ;;
    *)
        echo "Error: Unsupported platform: $(uname -s)-$(uname -m)" >&2
        echo "Supported: Linux (x86_64, aarch64), macOS (x86_64, arm64), Windows" >&2
        exit 1
        ;;
esac

# Find ALL matching wheels for this platform (nullglob-safe with set -euo pipefail)
shopt -s nullglob
wheels=( "$SCRIPT_DIR"/$WHEEL_PATTERN )
shopt -u nullglob

if (( ${#wheels[@]} == 0 )); then
    echo "Error: No compatible wheel found for this platform" >&2
    echo "Expected pattern: $WHEEL_PATTERN" >&2
    echo "Available wheels:" >&2
    shopt -s nullglob
    all_wheels=( "$SCRIPT_DIR"/*.whl )
    shopt -u nullglob
    if (( ${#all_wheels[@]} == 0 )); then
        echo "  (none)" >&2
    else
        for w in "${all_wheels[@]}"; do echo "  $(basename "$w")" >&2; done
    fi
    exit 1
fi

# Multiple Python-version wheels can match this platform (cp311/cp312/cp313).
# uv can't resolve two wheels for the same package in one invocation, so pick
# exactly one: newest supported version first.
wheel=""
PYTHON_PIN=""
for pyver in 3.13 3.12 3.11; do
    cptag="cp${pyver//./}"
    for w in "${wheels[@]}"; do
        if [[ "$(basename "$w")" == *"$cptag"* ]]; then
            wheel="$w"
            PYTHON_PIN="$pyver"
            break 2
        fi
    done
done

if [[ -z "$wheel" ]]; then
    echo "Error: No wheel for this platform matches a supported Python version (3.11-3.13)" >&2
    for w in "${wheels[@]}"; do echo "  $(basename "$w")" >&2; done
    exit 1
fi

# Clear Python-specific environment variables to prevent path contamination
unset PYTHONPATH PYTHONHOME PYTHONSTARTUP PYTHON
export PYTHONNOUSERSITE=1

# DataRobot Codespace FIPS images (3.12/3.13 envs) ship no system Python 3.11, so uv
# downloads a managed CPython whose statically linked OpenSSL 3.x reads the image's
# FIPS-only /etc/ssl/openssl.cnf (no default provider) and fails with
# [SSL: LIBRARY_HAS_NO_CIPHERS] on the first SSLContext. Scoped mitigation: only inside
# a DR Codespace, only if the probe fails, and only if the override provably fixes it.
# Never applied on customer machines, where OPENSSL_CONF may enforce crypto policy.
SSL_PROBE='import ssl; ssl.create_default_context()'
if [[ -n "${DATAROBOT_NOTEBOOK_IMAGE_VERSION:-}" && -z "${OPENSSL_CONF:-}" ]]; then
    if ! uv run -q --no-project --python "$PYTHON_PIN" python -c "$SSL_PROBE" 2>/dev/null; then
        if OPENSSL_CONF=/dev/null uv run -q --no-project --python "$PYTHON_PIN" python -c "$SSL_PROBE" 2>/dev/null; then
            export OPENSSL_CONF=/dev/null
            echo "Note: OpenSSL FIPS config on this Codespace image is incompatible with uv-managed Python; using compiled-in OpenSSL defaults for dr-assist only." >&2
        fi
    fi
fi

# Use a persistent venv instead of `uv run --with` to avoid extras resolution failing offline.
# Venv path includes the wheel filename so upgrades automatically get a fresh venv.
VENV_NAME="dr-assist-venv-$(basename "$wheel" .whl)"
# Probe XDG_CACHE_HOME first (runtime mount), then HOME/.cache (image-baked); fall back to creating in XDG_CACHE_HOME.
if [[ -n "${XDG_CACHE_HOME:-}" && -f "$XDG_CACHE_HOME/$VENV_NAME/bin/dr-assist" ]]; then
    VENV_DIR="$XDG_CACHE_HOME/$VENV_NAME"
elif [[ -f "$HOME/.cache/$VENV_NAME/bin/dr-assist" ]]; then
    VENV_DIR="$HOME/.cache/$VENV_NAME"
else
    VENV_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/$VENV_NAME"
    uv venv --clear --python "$PYTHON_PIN" "$VENV_DIR" >&2
    uv pip install --python "$VENV_DIR/bin/python" "$wheel" >&2
fi
exec "$VENV_DIR/bin/dr-assist" "$@"
