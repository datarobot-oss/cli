# dr-assist - AI agent design, coding, and deployment assistant
# This script wraps the dr-assist Python package using uv

$ErrorActionPreference = "Stop"

# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Handle --dr-plugin-manifest flag for CLI integration (must be fast, no deps)
if ($args.Count -gt 0 -and $args[0] -eq "--dr-plugin-manifest") {
    Write-Output '{"name":"assist","version":"0.1.36","description":"AI agent design, coding, and deployment assistant","authentication":true}'
    exit 0
}

# Check if uv is available
$uvPath = Get-Command uv -ErrorAction SilentlyContinue
if (-not $uvPath) {
    Write-Host "Error: dr-assist requires 'uv' (fast Python package manager)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Install uv:" -ForegroundColor Yellow
    Write-Host "  PowerShell:  irm https://astral.sh/uv/install.ps1 | iex"
    Write-Host "  Scoop:       scoop install uv"
    Write-Host ""
    Write-Host "Then retry: dr assist"
    exit 1
}

# Find ALL Windows wheels (win_amd64) - will match all Python versions
$WheelPattern = "*win_amd64*.whl"
$Wheels = Get-ChildItem -Path $ScriptDir -Filter $WheelPattern -ErrorAction SilentlyContinue

if ($Wheels.Count -eq 0) {
    Write-Host "Error: No compatible wheel found for Windows" -ForegroundColor Red
    Write-Host "Expected pattern: $WheelPattern"
    Write-Host "Available wheels:"
    Get-ChildItem -Path $ScriptDir -Filter "*.whl" | ForEach-Object { Write-Host "  $($_.Name)" }
    exit 1
}

# Validate exactly one wheel per platform (Python 3.11 pinned distribution)
if ($Wheels.Count -ne 1) {
    Write-Host "Error: Expected exactly 1 wheel for this platform, found $($Wheels.Count)" -ForegroundColor Red
    $Wheels | ForEach-Object { Write-Host "  $($_.Name)" }
    exit 1
}

# Clear Python-specific environment variables to prevent path contamination
$env:PYTHONPATH = $null
$env:PYTHONHOME = $null
$env:PYTHONSTARTUP = $null
$env:PYTHONNOUSERSITE = "1"
& uv run --no-project --python 3.11 --with $Wheels[0].FullName dr-assist @args
exit $LASTEXITCODE
