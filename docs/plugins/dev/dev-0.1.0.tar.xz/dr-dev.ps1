#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# dr-dev - Windows entrypoint
# Routes `dr dev` to the drdev command shipped with the DataRobot SDK.
# ---------------------------------------------------------------------------

if ($args.Count -ge 1 -and $args[0] -eq '--dr-plugin-manifest') {
    Write-Output '{"name":"dev","version":"0.1.0","description":"Start development services from .taskfile-data.yaml or command line","authentication":false}'
    exit 0
}

$drdev = Get-Command drdev -ErrorAction SilentlyContinue
if (-not $drdev) {
    Write-Error "dr dev requires the drdev command, which ships with the DataRobot SDK. Install it with: pip install 'datarobot[core]'"
    exit 1
}

& $drdev.Source @args
exit $LASTEXITCODE
