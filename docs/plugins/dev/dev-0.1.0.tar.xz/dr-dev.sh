#!/usr/bin/env bash
set -euo pipefail

# ---------------------------------------------------------------------------
# dr-dev — Unix entrypoint
# Routes `dr dev` to the drdev command shipped with the DataRobot SDK.
# Handles: --dr-plugin-manifest | forwarding every other argument
# ---------------------------------------------------------------------------

# Answered inline so discovery needs no interpreter and no dependencies.
if [[ "${1:-}" == "--dr-plugin-manifest" ]]; then
    cat << 'MANIFEST'
{"name":"dev","version":"0.1.0","description":"Start development services from .taskfile-data.yaml or command line","authentication":false}
MANIFEST
    exit 0
fi

if ! command -v drdev >/dev/null 2>&1; then
    cat >&2 << 'MISSING'
dr dev requires the drdev command, which ships with the DataRobot SDK.

    pip install 'datarobot[core]'

MISSING
    exit 1
fi

exec drdev "$@"
