# dr-experimentation — Windows entrypoint (wheel-based distribution)
# Installs app_backend from a pre-built wheel; no source code required.
# Handles: --dr-plugin-manifest | foreground launch

$ErrorActionPreference = "Stop"

# Resolve the directory this script lives in
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---------------------------------------------------------------------------
# --dr-plugin-manifest  (required by DR CLI discovery protocol)
# ---------------------------------------------------------------------------

if ($args.Count -gt 0 -and $args[0] -eq "--dr-plugin-manifest") {
    Get-Content (Join-Path $ScriptDir "manifest.json") -Raw
    exit 0
}


# ---------------------------------------------------------------------------
# Launch (foreground)
# ---------------------------------------------------------------------------

$ServerExe = Join-Path $ScriptDir "dr-experimentation-server-windows-amd64.exe"
if (-not (Test-Path $ServerExe)) {
    Write-Error "Error: Server binary not found at $ServerExe"
    exit 1
}

& $ServerExe @args
exit $LASTEXITCODE
