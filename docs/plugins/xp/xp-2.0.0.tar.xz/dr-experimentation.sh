#!/usr/bin/env bash
set -euo pipefail

# ---------------------------------------------------------------------------
# dr-experimentation — Unix entrypoint (wheel-based distribution)
# Installs app_backend from a pre-built wheel; no source code required.
# Handles: --dr-plugin-manifest | foreground launch
# ---------------------------------------------------------------------------

SOURCE="${BASH_SOURCE[0]}"
while [ -L "$SOURCE" ]; do
  DIR="$(cd "$(dirname "$SOURCE")" && pwd)"
  SOURCE="$(readlink "$SOURCE")"
  [[ "$SOURCE" != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$(cd "$(dirname "$SOURCE")" && pwd)"

# ---------------------------------------------------------------------------
# --dr-plugin-manifest  (required by DR CLI discovery protocol)
# ---------------------------------------------------------------------------

if [ "${1:-}" = "--dr-plugin-manifest" ]; then
  cat "$DIR/manifest.json"
  exit 0
fi

# ---------------------------------------------------------------------------
# Launch (foreground)
# ---------------------------------------------------------------------------

case "$(uname -s)-$(uname -m)" in
  Darwin-arm64)  SERVER_BIN="$DIR/dr-experimentation-server-darwin-arm64" ;;
  Darwin-x86_64) SERVER_BIN="$DIR/dr-experimentation-server-darwin-amd64" ;;
  Linux-x86_64)  SERVER_BIN="$DIR/dr-experimentation-server-linux-amd64" ;;
  Linux-aarch64) SERVER_BIN="$DIR/dr-experimentation-server-linux-arm64" ;;
  *)
    echo "Error: Unsupported platform: $(uname -s)-$(uname -m)" >&2
    exit 1
    ;;
esac

if [ ! -f "$SERVER_BIN" ]; then
  echo "Error: Server binary not found at $SERVER_BIN" >&2
  exit 1
fi
chmod +x "$SERVER_BIN"

exec "$SERVER_BIN" "$@"
