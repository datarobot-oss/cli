#!/bin/sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

case "$(uname -s)-$(uname -m)" in
    Linux-x86_64|Linux-amd64)   BINARY="opencode-linux-amd64" ;;
    Linux-aarch64|Linux-arm64)  BINARY="opencode-linux-arm64" ;;
    Linux-riscv64)              BINARY="opencode-linux-riscv64" ;;
    Darwin-x86_64)              BINARY="opencode-darwin-amd64" ;;
    Darwin-arm64)               BINARY="opencode-darwin-arm64" ;;
    *)
        echo "Error: Unsupported platform: $(uname -s)-$(uname -m)" >&2
        echo "Supported: Linux (x86_64, amd64, aarch64, arm64, riscv64), macOS (x86_64, arm64)" >&2
        exit 1
        ;;
esac

exec "$SCRIPT_DIR/$BINARY" "$@"
