#!/bin/sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

case "$(uname -s)-$(uname -m)" in
    Linux-x86_64|Linux-amd64)   BINARY="dr-codespace-linux-x64" ;;
    Darwin-arm64)               BINARY="dr-codespace-macos-arm64" ;;
    Darwin-x86_64)              BINARY="dr-codespace-macos-x64" ;;
    *)
        echo "Error: Unsupported platform: $(uname -s)-$(uname -m)" >&2
        echo "Supported: Linux (x86_64), macOS (arm64, x86_64)" >&2
        exit 1
        ;;
esac

exec "$SCRIPT_DIR/$BINARY" "$@"
