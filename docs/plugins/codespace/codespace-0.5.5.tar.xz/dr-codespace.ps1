$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$Arch = $env:PROCESSOR_ARCHITECTURE
switch ($Arch) {
    "AMD64" { $Binary = "dr-codespace-win-x64.exe" }
    default {
        Write-Host "Error: Unsupported architecture: $Arch" -ForegroundColor Red
        Write-Host "Supported: AMD64"
        exit 1
    }
}

$BinaryPath = Join-Path $ScriptDir $Binary
& $BinaryPath @args
exit $LASTEXITCODE
